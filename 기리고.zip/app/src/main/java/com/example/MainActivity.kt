package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.WishDatabase
import com.example.data.WishEntity
import com.example.data.WishRepository
import com.example.receiver.WishNotificationHelper
import com.example.ui.theme.DarkSlate
import com.example.ui.theme.JetBlack
import com.example.ui.theme.BloodRed
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.GhostWhite
import com.example.ui.theme.SoftGray
import com.example.ui.theme.CreepyGreen
import com.example.ui.theme.OccultGold
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.WishViewModel
import com.example.viewmodel.WishViewModelFactory
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

// CameraX and Bitmap processing imports
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.ui.viewinterop.AndroidView
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File
import androidx.compose.ui.draw.scale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = WishDatabase.getDatabase(applicationContext)
        val repository = WishRepository(database.wishDao())

        setContent {
            MyApplicationTheme {
                val viewModel: WishViewModel = viewModel(
                    factory = WishViewModelFactory(
                        application = application,
                        repository = repository
                    )
                )

                // Scaffold with safe drawing padding
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    GirigoWishAppScreen(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun GirigoWishAppScreen(
    viewModel: WishViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activeWish by viewModel.activeWish.collectAsStateWithLifecycle()
    val allWishes by viewModel.allWishes.collectAsStateWithLifecycle()
    val remainingTimeMs by viewModel.remainingTimeMs.collectAsStateWithLifecycle()
    val isCreepyMode by viewModel.isCreepyMode.collectAsStateWithLifecycle()
    val spookyMessage by viewModel.spookyMessage.collectAsStateWithLifecycle()
    val heartbeatRateMs by viewModel.heartbeatRateMs.collectAsStateWithLifecycle()
    val hasJustExpired by viewModel.hasJustExpired.collectAsStateWithLifecycle()

    var wishInput by remember { mutableStateOf("") }
    var showHistory by remember { mutableStateOf(false) }
    var showDeveloperPanel by remember { mutableStateOf(false) }
    var isBreakingPactPromptOpen by remember { mutableStateOf(false) }

    // Dynamic scale for the creepy pulse
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_trans")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isCreepyMode) 1.12f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = heartbeatRateMs.toInt(),
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Dynamic red heartbeat overlay alpha
    val pulseOverlayAlpha by infiniteTransition.animateFloat(
        initialValue = 0.05f,
        targetValue = if (isCreepyMode) 0.35f else 0.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = heartbeatRateMs.toInt(),
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    // Glitch offset state for creepy mode
    var glitchOffset by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(isCreepyMode) {
        if (isCreepyMode) {
            while (true) {
                glitchOffset = if (Random.nextInt(5) == 0) {
                    Offset(
                        x = Random.nextInt(-8, 9).toFloat(),
                        y = Random.nextInt(-8, 9).toFloat()
                    )
                } else {
                    Offset.Zero
                }
                delay(120L)
            }
        } else {
            glitchOffset = Offset.Zero
        }
    }

    // Dynamic blood drips simulation state
    val bloodDrips = remember { mutableStateListOf<BloodDrip>() }
    LaunchedEffect(isCreepyMode) {
        if (isCreepyMode) {
            // Seed blood drips
            if (bloodDrips.isEmpty()) {
                repeat(8) {
                    bloodDrips.add(
                        BloodDrip(
                            x = Random.nextFloat(),
                            y = Random.nextFloat() * -0.5f,
                            length = Random.nextFloat() * 100f + 50f,
                            speed = Random.nextFloat() * 4f + 2f
                        )
                    )
                }
            }
            while (true) {
                for (i in bloodDrips.indices) {
                    val drip = bloodDrips[i]
                    var newY = drip.y + (drip.speed / 1000f)
                    if (newY > 1.2f) {
                        newY = -0.1f
                    }
                    bloodDrips[i] = drip.copy(y = newY)
                }
                delay(16)
            }
        } else {
            bloodDrips.clear()
        }
    }

    // Initialize notification channel
    LaunchedEffect(Unit) {
        WishNotificationHelper.initChannel(context)
    }

    // Handle Notification Permission (Android 13+)
    var hasNotificationPermission by remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            mutableStateOf(
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            )
        } else {
            mutableStateOf(true)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Spirit Camera Permissions and States
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var isInputFormVisible by remember { mutableStateOf(false) }
    var isCapturing by remember { mutableStateOf(false) }
    var flashActive by remember { mutableStateOf(false) }

    // Real-Time Mystic Running Clock (Matches '7 12 12' Vertical format)
    var systemTimeText by remember { mutableStateOf("07 12 12") }
    LaunchedEffect(Unit) {
        while (true) {
            val sdf = SimpleDateFormat("H mm ss", Locale.getDefault())
            systemTimeText = sdf.format(Date())
            delay(1000L)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JetBlack)
    ) {
        if (hasCameraPermission) {
            CameraPreview(
                modifier = Modifier.fillMaxSize(),
                onImageCaptureReady = { capture ->
                    imageCapture = capture
                }
            )
            // Black transparent overlay to desaturate/darken the camera feed to fit the spooky mood
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
            )
        } else {
            // Atmospheric Gothic Background Image with custom blood red overlay
            Image(
                painter = painterResource(id = R.drawable.img_gothic_well),
                contentDescription = "Gothic Well",
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(if (isCreepyMode) 0.15f else 0.3f),
                contentScale = ContentScale.Crop,
                colorFilter = ColorFilter.tint(
                    color = if (isCreepyMode) BloodRed else Color.Unspecified,
                    blendMode = androidx.compose.ui.graphics.BlendMode.ColorBurn
                )
            )
        }

        // Vignette Blood and Shadow Glow overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    val center = Offset(size.width / 2, size.height / 2)
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.5f),
                                Color.Black.copy(alpha = 0.95f)
                            ),
                            center = center,
                            radius = size.width * 1.0f
                        )
                    )
                }
        )

        // Vignette Blood Glow overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    val center = Offset(size.width / 2, size.height / 2)
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.Transparent,
                                BloodRed.copy(alpha = pulseOverlayAlpha)
                            ),
                            center = center,
                            radius = size.width * 1.2f
                        )
                    )
                }
        )

        // Dripping blood Canvas overlay
        if (isCreepyMode) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                bloodDrips.forEach { drip ->
                    val dripX = drip.x * size.width
                    val dripY = drip.y * size.height
                    drawLine(
                        color = CrimsonRed.copy(alpha = 0.85f),
                        start = Offset(dripX, dripY),
                        end = Offset(dripX, dripY + drip.length),
                        strokeWidth = 6f
                    )
                    drawCircle(
                        color = CrimsonRed,
                        radius = 8f,
                        center = Offset(dripX, dripY + drip.length)
                    )
                }
            }
        }

        // Screen Flash feedback during capture
        AnimatedVisibility(
            visible = flashActive,
            enter = fadeIn(animationSpec = tween(50)),
            exit = fadeOut(animationSpec = tween(150))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White)
            )
        }

        val scope = rememberCoroutineScope()
        val currentActive = activeWish

        // Main Scrollable Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            // Spooky Spacing
            item { Spacer(modifier = Modifier.height(24.dp)) }

            // App Header (Bold Typography Theme matching reference image)
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 16.dp, bottom = 12.dp)
                ) {
                    Text(
                        text = if (activeWish != null) "소원이 기리고 있습니다" else "소원을 기리고, 간직하세요",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Medium,
                            fontSize = 18.sp,
                            color = Color.White,
                            letterSpacing = 2.sp,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier
                            .padding(bottom = 4.dp)
                            .testTag("app_title")
                    )
                    Text(
                        text = if (activeWish != null) "THE COUNTDOWN COMMENCES" else "CHERISH YOUR WISH AND KEEP IT CLOSE",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.ExtraLight,
                            fontSize = 10.sp,
                            color = Color(0xFFFF3131),
                            letterSpacing = 2.sp,
                            textAlign = TextAlign.Center
                        )
                    )
                }
            }

            // Central State Handling
            if (currentActive == null) {
                // STATE A: Landing / Wish-Making Screen mimicking reference image
                item {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        // 1. Stylized clock H MM SS representing current time (matching "7 12 12" style)
                        val timeParts = systemTimeText.split(" ")
                        val hr = timeParts.getOrNull(0) ?: "07"
                        val mn = timeParts.getOrNull(1) ?: "12"
                        val sc = timeParts.getOrNull(2) ?: "12"

                        Text(
                            text = "$hr $mn $sc",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraLight,
                                fontSize = 44.sp,
                                color = Color.White.copy(alpha = 0.9f),
                                letterSpacing = 6.sp,
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // 2. Beautiful white charcoal Praying Hands sketch (pulsing with heartbeat)
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .clickable {
                                    isInputFormVisible = true
                                }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_praying_hands_1782647521443),
                                contentDescription = "Praying Hands",
                                modifier = Modifier
                                    .size(200.dp)
                                    .scale(pulseScale)
                                    .clip(RoundedCornerShape(16.dp))
                                    .border(
                                        width = 1.dp,
                                        color = Color(0xFF4D0000).copy(alpha = 0.4f),
                                        shape = RoundedCornerShape(16.dp)
                                    ),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // 3. Stylized "소원 빌기" label and sub-action
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable {
                                    isInputFormVisible = true
                                }
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "소원 빌기",
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Light,
                                    fontSize = 24.sp,
                                    color = Color.White,
                                    letterSpacing = 4.sp,
                                    textAlign = TextAlign.Center
                                ),
                                modifier = Modifier.scale(pulseScale)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "TAP TO COMMENCE COVENANT",
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp,
                                    color = Color(0xFFFF3131),
                                    letterSpacing = 1.5.sp
                                )
                            )
                        }

                        // Spirit Camera Action overlay if camera permission is denied
                        if (!hasCameraPermission) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF1A0000),
                                    contentColor = Color(0xFFFF3131)
                                ),
                                border = BorderStroke(1.dp, Color(0xFF4D0000)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("enable_camera_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "ACTIVATE SPIRIT CAMERA BACKDROP",
                                    fontFamily = FontFamily.SansSerif,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }
                        }

                        // 4. Slide-up Wish Input Card (SACRED COVENANT INPUT)
                        AnimatedVisibility(
                            visible = isInputFormVisible,
                            enter = fadeIn(animationSpec = tween(400)),
                            exit = fadeOut(animationSpec = tween(400))
                        ) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 16.dp)
                                    .border(1.5.dp, Color(0xFFFF3131).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                    .testTag("input_card"),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0000).copy(alpha = 0.95f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "소원 입력 (PACT INPUT)",
                                            style = TextStyle(
                                                fontFamily = FontFamily.SansSerif,
                                                fontWeight = FontWeight.Black,
                                                fontSize = 13.sp,
                                                color = Color(0xFFFF3131),
                                                letterSpacing = 1.5.sp
                                            )
                                        )
                                        IconButton(
                                            onClick = { isInputFormVisible = false }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Close",
                                                tint = Color.White
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Text(
                                        text = "By sealing this pact, your face and environment will be captured by the camera preview onto Girigo's sacred chronicle.",
                                        style = TextStyle(
                                            fontFamily = FontFamily.SansSerif,
                                            fontSize = 11.sp,
                                            color = Color(0xFFFFBABA),
                                            textAlign = TextAlign.Center,
                                            lineHeight = 15.sp
                                        ),
                                        modifier = Modifier.padding(bottom = 16.dp)
                                    )

                                    TextField(
                                        value = wishInput,
                                        onValueChange = { wishInput = it },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(90.dp)
                                            .border(1.dp, Color(0xFF4D0000), RoundedCornerShape(8.dp))
                                            .testTag("wish_input"),
                                        placeholder = {
                                            Text(
                                                text = "Whisper your desire to Girigo...",
                                                color = Color(0xFFFFBABA).copy(alpha = 0.4f),
                                                fontFamily = FontFamily.SansSerif,
                                                fontSize = 13.sp
                                            )
                                        },
                                        textStyle = TextStyle(
                                            fontFamily = FontFamily.SansSerif,
                                            fontSize = 14.sp,
                                            color = Color(0xFFE0E0E0)
                                        ),
                                        colors = TextFieldDefaults.colors(
                                            focusedContainerColor = Color(0xFF020000),
                                            unfocusedContainerColor = Color(0xFF020000),
                                            focusedIndicatorColor = Color(0xFFFF3131),
                                            unfocusedIndicatorColor = Color(0xFF4D0000),
                                            cursorColor = Color(0xFFFF3131)
                                        ),
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    Spacer(modifier = Modifier.height(16.dp))

                                    Button(
                                        onClick = {
                                            if (wishInput.isNotBlank()) {
                                                val activeCapture = imageCapture
                                                if (hasCameraPermission && activeCapture != null) {
                                                    isCapturing = true
                                                    flashActive = true
                                                    scope.launch {
                                                        delay(150)
                                                        flashActive = false
                                                    }
                                                    capturePhoto(context, activeCapture, onCaptured = { path ->
                                                        isCapturing = false
                                                        viewModel.makeWish(wishInput, path)
                                                        wishInput = ""
                                                        isInputFormVisible = false
                                                    }, onError = { exc ->
                                                        isCapturing = false
                                                        viewModel.makeWish(wishInput, null)
                                                        wishInput = ""
                                                        isInputFormVisible = false
                                                    })
                                                } else {
                                                    viewModel.makeWish(wishInput, null)
                                                    wishInput = ""
                                                    isInputFormVisible = false
                                                }
                                            }
                                        },
                                        enabled = wishInput.isNotBlank() && !isCapturing,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(50.dp)
                                            .testTag("seal_pact_button"),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFFFF3131),
                                            contentColor = Color(0xFF000000),
                                            disabledContainerColor = Color(0xFF4D0000),
                                            disabledContentColor = Color(0xFFFFBABA).copy(alpha = 0.4f)
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        if (isCapturing) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(20.dp),
                                                color = Color.Black,
                                                strokeWidth = 2.dp
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Default.Warning,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = Color.Black
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "소원 빌기 (SEAL COVENANT)",
                                                fontFamily = FontFamily.SansSerif,
                                                fontWeight = FontWeight.Black,
                                                fontSize = 12.sp,
                                                letterSpacing = 1.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // STATE B: Active Wish & Countdown (Bold Typography Style)
                item {
                    val progress = remainingTimeMs.toDouble() / (24 * 60 * 60 * 1000L)
                    val displayTime = formatTime(remainingTimeMs)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.5.dp,
                                color = if (isCreepyMode) Color(0xFFFF0000) else Color(0xFF4D0000),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .testTag("active_wish_card"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isCreepyMode) Color(0xFF130303) else Color(0xFF1A0000)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(24.dp)
                                .fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Pact Status Header
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color(0xFFFF3131), RoundedCornerShape(4.dp))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isCreepyMode) "CURSE SEED IS FULLY DETONATED" else "PACT ACTIVE & DESIRE SEALED",
                                    style = TextStyle(
                                        fontFamily = FontFamily.SansSerif,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp,
                                        color = Color(0xFFFF3131),
                                        letterSpacing = 1.5.sp
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Captured Pact image preview
                            val activePhotoBitmap = rememberBitmapFromPath(currentActive.photoPath)
                            if (activePhotoBitmap != null) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .padding(bottom = 16.dp)
                                        .size(160.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(2.dp, Color(0xFFFF3131), RoundedCornerShape(12.dp))
                                ) {
                                    Image(
                                        bitmap = activePhotoBitmap,
                                        contentDescription = "Sacred Capture Aura",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                    // Spectral overlay tint
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Color(0xFFFF3131).copy(alpha = 0.15f))
                                    )
                                }
                            } else {
                                // Fallback: pulsing praying hands sketch as a spiritual indicator
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .padding(bottom = 16.dp)
                                        .size(100.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, Color(0xFF4D0000).copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_praying_hands_1782647521443),
                                        contentDescription = "Praying Hands",
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .scale(pulseScale),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }

                            // Wish Text Box
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = Color(0xFF0A0000),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = Color(0xFF4D0000),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .padding(16.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "YOUR WHISPERED REQUEST",
                                        style = TextStyle(
                                            fontFamily = FontFamily.SansSerif,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp,
                                            color = Color(0xFFFFBABA),
                                            letterSpacing = 1.sp
                                        ),
                                        modifier = Modifier.fillMaxWidth(),
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "\"${currentActive.wishText}\"",
                                        style = TextStyle(
                                            fontFamily = FontFamily.SansSerif,
                                            fontWeight = FontWeight.Normal,
                                            fontSize = 15.sp,
                                            color = Color(0xFFE0E0E0),
                                            textAlign = TextAlign.Center,
                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .offset(
                                                x = glitchOffset.x.dp,
                                                y = glitchOffset.y.dp
                                            )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            // Dual-Ring Circular Countdown Timer (Exact Bold Typography styling)
                            Box(
                                modifier = Modifier
                                    .size(220.dp)
                                    .align(Alignment.CenterHorizontally),
                                contentAlignment = Alignment.Center
                            ) {
                                // Outer border ring
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .border(1.dp, Color(0xFF4D0000).copy(alpha = 0.5f), RoundedCornerShape(110.dp))
                                )
                                // Inner pulsing ring
                                Box(
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .fillMaxSize()
                                        .border(2.dp, Color(0xFFFF0000).copy(alpha = pulseOverlayAlpha), RoundedCornerShape(102.dp))
                                )

                                // Centered Timer Details
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .padding(16.dp)
                                        .offset(x = glitchOffset.x.dp, y = glitchOffset.y.dp)
                                ) {
                                    Text(
                                        text = if (isCreepyMode) "TIME TILL CLAIM" else "FINAL COUNTDOWN",
                                        style = TextStyle(
                                            fontFamily = FontFamily.SansSerif,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 9.sp,
                                            color = Color(0xFFFF3131).copy(alpha = 0.7f),
                                            letterSpacing = 3.sp,
                                            textAlign = TextAlign.Center
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = displayTime,
                                        style = TextStyle(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 32.sp,
                                            color = Color(0xFFFF3131),
                                            letterSpacing = (-0.5).sp,
                                            textAlign = TextAlign.Center
                                        ),
                                        modifier = Modifier
                                            .scale(pulseScale)
                                            .testTag("countdown_timer")
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .background(Color(0xFFFF0000), RoundedCornerShape(3.dp))
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Synchronizing...",
                                            style = TextStyle(
                                                fontFamily = FontFamily.SansSerif,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 11.sp,
                                                color = Color(0xFFFFBABA),
                                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                            )
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            // Dynamic Warning Message
                            Text(
                                text = spookyMessage,
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontSize = 12.sp,
                                    color = Color(0xFFFF3131),
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .alpha(if (isCreepyMode) 1.0f else 0.8f)
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            // Simple linear timeline of remaining pact
                            LinearProgressIndicator(
                                progress = { progress.toFloat() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp),
                                color = Color(0xFFFF3131),
                                trackColor = Color(0xFF0A0000)
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            // Sever Pact Action Button (Heavy Outlined Black Style)
                            OutlinedButton(
                                onClick = { isBreakingPactPromptOpen = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("sever_pact_button"),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFFFF3131)
                                ),
                                border = BorderStroke(
                                    width = 1.5.dp,
                                    color = Color(0xFF4D0000)
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = Color(0xFFFF3131)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "SEVER THE PACT",
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                            }
                        }
                    }
                }
            }

            // Collapsible Past Chronicles (History)
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, Color(0xFF4D0000), RoundedCornerShape(12.dp))
                        .testTag("history_collapsible_header"),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A0000)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showHistory = !showHistory }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.List,
                                contentDescription = null,
                                tint = Color(0xFFFF3131),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "CHRONICLE OF GRANTED DESIRES",
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 12.sp,
                                color = Color(0xFFE0E0E0),
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp
                            )
                        }
                        Icon(
                            imageVector = if (showHistory) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            tint = Color(0xFFFFBABA)
                        )
                    }
                }
            }

            if (showHistory) {
                if (allWishes.isEmpty()) {
                    item {
                        Text(
                            text = "No pacts have been sealed in the ledger yet...",
                            color = Color(0xFFFFBABA),
                            fontSize = 12.sp,
                            fontFamily = FontFamily.SansSerif,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                } else {
                    items(allWishes) { wish ->
                        HistoryWishItem(wish)
                    }
                    item {
                        Button(
                            onClick = { viewModel.clearAllHistory() },
                            modifier = Modifier
                                .padding(vertical = 12.dp)
                                .testTag("clear_history_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.Transparent,
                                contentColor = Color(0xFFFFBABA)
                            )
                        ) {
                            Text(
                                text = "WIPE CHRONICLE CLEAN",
                                textDecoration = TextDecoration.Underline,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }
            }

            // Collapsible Developer/Reviewer Curse Control Room (EXCELLENT FOR TESTING)
            if (activeWish != null) {
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dev_portal_header"),
                        colors = CardDefaults.cardColors(containerColor = CreepyGreen.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showDeveloperPanel = !showDeveloperPanel }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.Green,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Curse Control Room (Demo Mode)",
                                    fontFamily = FontFamily.Serif,
                                    fontSize = 14.sp,
                                    color = Color.Green,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Icon(
                                imageVector = if (showDeveloperPanel) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                tint = Color.Green,
                                contentDescription = null
                            )
                        }
                    }
                }

                if (showDeveloperPanel) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(0.5.dp, Color.Green.copy(alpha = 0.4f), RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp)),
                            colors = CardDefaults.cardColors(containerColor = JetBlack.copy(alpha = 0.9f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "To test the psychological impact without waiting 24 hours, warp the time remaining below:",
                                    style = TextStyle(
                                        fontFamily = FontFamily.Serif,
                                        fontSize = 12.sp,
                                        color = Color.Green,
                                        lineHeight = 16.sp
                                    ),
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    ControlWarpButton("24 Hours", "STANDARD", viewModel)
                                    ControlWarpButton("10 Minutes", "TEN_MINUTES", viewModel)
                                    ControlWarpButton("5m 10s (Transition)", "FIVE_MINUTES_TEN_SECONDS", viewModel)
                                    ControlWarpButton("10 Seconds (Claim)", "TEN_SECONDS", viewModel)
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Spacer to prevent gesture bar occlusion
            item { Spacer(modifier = Modifier.height(48.dp)) }
        }

        // FULL SCREEN OVERLAY: PACT COMPLETED (EXPIRED CURSE)
        AnimatedVisibility(
            visible = hasJustExpired,
            enter = fadeIn(animationSpec = tween(1200)),
            exit = fadeOut(animationSpec = tween(800))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF030000))
                    .testTag("expired_overlay"),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "💀 THE DEBT IS CLAIMED 💀",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Black,
                            fontSize = 26.sp,
                            color = Color(0xFFFF3131),
                            letterSpacing = 2.sp,
                            textAlign = TextAlign.Center
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "The 24-hour cycle has finished.\n\nGirigo has fulfilled your wish completely.\nThe price has been claimed in full.\n\nYour pact is permanently sealed.",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 15.sp,
                            color = Color(0xFFE0E0E0),
                            lineHeight = 22.sp,
                            textAlign = TextAlign.Center
                        )
                    )

                    Spacer(modifier = Modifier.height(48.dp))

                    Button(
                        onClick = { viewModel.dismissExpirationScreen() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("dismiss_expiry_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFF3131),
                            contentColor = Color(0xFF000000)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = "RETURN TO THE WELL",
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }
        }

        // DIALOG: SEVER PACT WARNING
        if (isBreakingPactPromptOpen) {
            AlertDialog(
                onDismissRequest = { isBreakingPactPromptOpen = false },
                title = {
                    Text(
                        text = "🪓 SEVER THE CONTRACT?",
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFF3131),
                        letterSpacing = 1.sp
                    )
                },
                text = {
                    Text(
                        text = "Severing the pact will permanently retract your granted desire, and may invite the wrath of the spirits. Do you dare anger Girigo?",
                        fontFamily = FontFamily.SansSerif,
                        color = Color(0xFFFFBABA)
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.breakPact()
                            isBreakingPactPromptOpen = false
                        },
                        modifier = Modifier.testTag("confirm_break_pact")
                    ) {
                        Text(
                            text = "YES, BREAK PACT",
                            color = Color(0xFFFF3131),
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { isBreakingPactPromptOpen = false }
                    ) {
                        Text(
                            text = "NO, STAY LOYAL",
                            color = Color(0xFFE0E0E0),
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                containerColor = Color(0xFF1A0000),
                shape = RoundedCornerShape(16.dp)
            )
        }
    }
}

@Composable
fun HistoryWishItem(wish: WishEntity) {
    val dateString = remember(wish.creationTime) {
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        sdf.format(Date(wish.creationTime))
    }
    val bitmap = rememberBitmapFromPath(wish.photoPath)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(1.dp, Color(0xFF4D0000), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A0000))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (wish.isCompleted) Icons.Default.CheckCircle else Icons.Default.Refresh,
                contentDescription = null,
                tint = if (wish.isCompleted) Color(0xFFFF3131) else Color(0xFFFFBABA),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "\"${wish.wishText}\"",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 14.sp,
                        color = Color(0xFFE0E0E0),
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Sealed: $dateString",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        color = Color(0xFFFFBABA)
                    )
                )
            }
            if (bitmap != null) {
                Spacer(modifier = Modifier.width(12.dp))
                Image(
                    bitmap = bitmap,
                    contentDescription = "Pact Aura",
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .border(1.dp, Color(0xFFFF3131), RoundedCornerShape(6.dp)),
                    contentScale = ContentScale.Crop
                )
            }
        }
    }
}

@Composable
fun ControlWarpButton(
    label: String,
    option: String,
    viewModel: WishViewModel
) {
    Button(
        onClick = { viewModel.simulateTimeRemaining(option) },
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF1B3B1B),
            contentColor = Color.Green
        ),
        shape = RoundedCornerShape(6.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        modifier = Modifier
            .height(32.dp)
            .testTag("warp_${option.lowercase()}")
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Medium
        )
    }
}

// Simple FlowRow helper for wrapping controls
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    content: @Composable () -> Unit
) {
    androidx.compose.foundation.layout.FlowRow(
        modifier = modifier,
        horizontalArrangement = horizontalArrangement,
        verticalArrangement = verticalArrangement,
        content = { content() }
    )
}

// Helper to format remaining milliseconds into hh:mm:ss
fun formatTime(milliseconds: Long): String {
    val totalSeconds = milliseconds / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds)
}

// Data class for Blood Drips animation
data class BloodDrip(
    val x: Float,
    val y: Float,
    val length: Float,
    val speed: Float
)

// Helper Modifier Extension for scaling
fun Modifier.scale(scale: Float): Modifier = this.then(
    Modifier.graphicsLayer(
        scaleX = scale,
        scaleY = scale
    )
)

@Composable
fun CameraPreview(
    modifier: Modifier = Modifier,
    onImageCaptureReady: (ImageCapture) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
    
    val previewView = remember { PreviewView(context).apply {
        scaleType = PreviewView.ScaleType.FILL_CENTER
    } }
    
    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
    }
    
    LaunchedEffect(cameraProviderFuture) {
        try {
            val cameraProvider = cameraProviderFuture.get()
            val preview = androidx.camera.core.Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
                lifecycleOwner,
                cameraSelector,
                preview,
                imageCapture
            )
            onImageCaptureReady(imageCapture)
        } catch (exc: Exception) {
            android.util.Log.e("CameraPreview", "Use case binding failed", exc)
        }
    }
    
    AndroidView(
        factory = { previewView },
        modifier = modifier
    )
}

fun capturePhoto(
    context: android.content.Context,
    imageCapture: ImageCapture,
    onCaptured: (String) -> Unit,
    onError: (Exception) -> Unit
) {
    val photoFile = File(
        context.cacheDir,
        "wish_capture_${System.currentTimeMillis()}.jpg"
    )
    val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()
    
    imageCapture.takePicture(
        outputOptions,
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                onCaptured(photoFile.absolutePath)
            }
            override fun onError(exception: ImageCaptureException) {
                onError(exception)
            }
        }
    )
}

@Composable
fun rememberBitmapFromPath(path: String?): androidx.compose.ui.graphics.ImageBitmap? {
    if (path == null) return null
    return remember(path) {
        try {
            val file = File(path)
            if (file.exists()) {
                BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap()
            } else {
                null
            }
        } catch (e: Exception) {
            android.util.Log.e("BitmapLoader", "Failed to decode photo: $path", e)
            null
        }
    }
}
